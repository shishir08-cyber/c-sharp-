using Microsoft.AspNetCore.Mvc;

namespace Exp9.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController : ControllerBase
    {
        [HttpGet]
        public string Get()
        {
            return "Product API Running";
        }
    }
}