using Microsoft.AspNetCore.Mvc;

namespace Exp6.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}